﻿#include <bangtal.h>
#include <vector>
#include "Card.h"

using namespace bangtal;

int main()
{

	setGameOption(GameOption::GAME_OPTION_INVENTORY_BUTTON, false);
	setGameOption(GameOption::GAME_OPTION_MESSAGE_BOX_BUTTON, false);
	auto scene1 = Scene::create("같은그림맞추기!", "images/jandi.png");

	std::vector<Card*> ObjectList;

	std::string route("images/");
	std::string png(".png");
	for (int i = 1; i <= 16; i++)
	{
		std::string strNum(std::to_string(i));

		int xpos, ypos;
				//sleep을 못써서 쓴거 lock처리 안됨
		if (i % 4 == 0)
			xpos = 750;
		else if (i % 4 == 1)
			xpos = 300;
		else if (i % 4 == 2)
			xpos = 450;
		else if (i % 4 == 3)
			xpos = 600;
		if (i >= 13)
			ypos = 20;
		else if (i >= 9)
			ypos = 170;
		else if (i >= 5)
			ypos = 320;
		else
			ypos = 470;
			
		strNum = "11111";
		auto cardObject = Object::create(route + strNum + png, scene1, xpos, ypos);
		strNum = "뒷면";
		Card* hidecard = new Card(i - 1, Object::create(route + strNum + png, scene1, xpos, ypos));
		ObjectList.push_back(hidecard);

	}
	auto timer = Timer::create(0.f); 
	bool bStart = false;
	bool bSetting = true;

	auto checktimer = Timer::create(0.f); 
	int checktime = 0;
	int Shorttime = 10000000;

	Card* ChoiceObject = NULL;
	int targetNum = -1;
	int correctcount = 0;
	for (int i = 0; i < 16; i++)
	{
		if (bSetting){
		int t = 0;
		ObjectList[i]->getCardObject()->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool {
			int Target = 0;
			for (int j = 0; j < 16; j++)
			{
				if (ObjectList[j]->getCardObject() == object)
					Target = j;
			}
			ObjectList[Target]->getCardObject()->hide();
			if (ChoiceObject)
			{
				if (ChoiceObject->getNum() / 4 == Target / 4)
				{
					correctcount ++;
					ChoiceObject = NULL;
				}
				else
				{
					bSetting = false;
					targetNum = Target;
					timer->set(0.2f);
					timer->start();
				}
				
			}
			else {
				ChoiceObject = ObjectList[Target];
			}
			
			return true;
			});
		}
	}

	auto startButton = Object::create("Images/start.png", scene1, 590, 70);

	startButton->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool {
		// start game
		startButton->hide();
		int num = rand() % 16;
		timer->set(1.f);
		timer->start();
		return true;
		});

	timer->setOnTimerCallback([&](TimerPtr timer)->bool {
		
		ObjectList[targetNum]->getCardObject()->show();
		ChoiceObject->getCardObject()->show();
		ChoiceObject = NULL;
		bSetting = true;
		return true;
		});
	checktimer->setOnTimerCallback([&](TimerPtr timer)->bool {
		
		checktimer->set(1.f);
		checktimer->start();
		checktime += 1;
		return true;
		});
	startGame(scene1);
	return 0;
}