﻿#include <bangtal.h>
#include <vector>
#include "Persol.h"

using namespace bangtal;

int main()
{

	setGameOption(GameOption::GAME_OPTION_INVENTORY_BUTTON, false);
	setGameOption(GameOption::GAME_OPTION_MESSAGE_BOX_BUTTON, false);
	auto scene1 = Scene::create("이미지 퍼즐!", "images/배경.png");

	std::vector<Persol*> ObjectList;

	std::string route("images/");
	std::string png(".png");
	for (int i = 1; i <= 16; i++)
	{
		std::string strNum(std::to_string(i));
		int xpos, ypos;
		if (i % 4 == 0)
			xpos = 750;
		else if (i % 4 == 1)
			xpos = 300;
		else if (i % 4 == 2)
			xpos = 450;
		else if (i % 4 == 3)
			xpos = 600;
		if (i >= 13)
			ypos = 20;
		else if (i >= 9)
			ypos = 170;
		else if (i >= 5)
			ypos = 320;
		else
			ypos = 470;
		Persol* persol = new Persol(xpos, ypos, Object::create(route + strNum + png, scene1, xpos, ypos), scene1);
		ObjectList.push_back(persol);
	}
	auto timer = Timer::create(10.f); // 셔플 하는데 쓰기위한 타이머
	int count = 0;
	bool bStart = false;

	auto checktimer = Timer::create(0.f); // 경과시간 알려주기 위한 타이머
	int checktime = 0;
	int Shorttime = 10000000;

	auto startButton = Object::create("Images/start.png", scene1, 590, 70);

	startButton->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool {
		// start game
		startButton->hide();
		int num = rand() % 16;
		ObjectList[num]->getPersolObject()->hide();
		ObjectList[num]->setHide(true);
		timer->set(1.f);
		timer->start();
		return true;
		});

	for (int i = 0; i < 16; i++)
	{
		ObjectList[i]->getPersolObject()->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool {
			if (bStart)
			{
				int Target = 0;
				for (int j = 0; j < 16; j++)
				{
					if (ObjectList[j]->getPersolObject() == object)
						Target = j;
				}
				for (int j = 0; j < 16; j++)
				{
					if ((ObjectList[Target]->getXPos() - 150 == ObjectList[j]->getXPos() && ObjectList[Target]->getYPos() == ObjectList[j]->getYPos() && ObjectList[j]->getHide()) ||
						(ObjectList[Target]->getXPos() + 150 == ObjectList[j]->getXPos() && ObjectList[Target]->getYPos() == ObjectList[j]->getYPos() && ObjectList[j]->getHide()) ||
						(ObjectList[Target]->getXPos() == ObjectList[j]->getXPos() && ObjectList[Target]->getYPos() - 150 == ObjectList[j]->getYPos() && ObjectList[j]->getHide()) ||
						(ObjectList[Target]->getXPos() == ObjectList[j]->getXPos() && ObjectList[Target]->getYPos() + 150 == ObjectList[j]->getYPos() && ObjectList[j]->getHide()))
					{
						ObjectList[Target]->ChangePos(ObjectList[j]);
						break;
					}
				}
				int xpos, ypos;
				for (int j = 1; j <= 16; j++)
				{
					if (j % 4 == 0)
						xpos = 750;
					else if (j % 4 == 1)
						xpos = 300;
					else if (j % 4 == 2)
						xpos = 450;
					else if (j % 4 == 3)
						xpos = 600;
					if (j >= 13)
						ypos = 20;
					else if (j >= 9)
						ypos = 170;
					else if (j >= 5)
						ypos = 320;
					else
						ypos = 470;
					int num = j - 1;
					if (!(ObjectList[num]->getXPos() == xpos && ObjectList[num]->getYPos() == ypos))
						return true;
				}

				std::string strTime(std::to_string(checktime));
				if (Shorttime > checktime)
					Shorttime = checktime;
				strTime += "초 걸렸습니다!\n";
				strTime += "최단시간은 : ";
				strTime += std::to_string(Shorttime);
				strTime += "초!";
				checktimer->set(0.f);
				checktimer->stop();
				checktime = 0;
				startButton->show();
				bStart = 0;

				for (int num = 0; num < 16; num++)
				{
					if (ObjectList[num]->getHide())
					{
						ObjectList[num]->getPersolObject()->show();
						ObjectList[num]->setHide(false);
					}
				}

				showMessage(strTime.c_str());

			}
			return true;
			});
	}

	timer->setOnTimerCallback([&](TimerPtr timer)->bool {
		for (int j = 0; j < 16; j++)
		{
			if (ObjectList[j]->getHide())
			{
				int random = rand() % 4;
				if (random == 0)
					for (int k = 0; k < 16; k++)
					{
						if (ObjectList[j]->getXPos() - 150 == ObjectList[k]->getXPos() && ObjectList[j]->getYPos() == ObjectList[k]->getYPos())
						{
							ObjectList[j]->ChangePos(ObjectList[k]);
							break;
						}
					}
				else if (random == 1)
					for (int k = 0; k < 16; k++)
					{
						if (ObjectList[j]->getXPos() + 150 == ObjectList[k]->getXPos() && ObjectList[j]->getYPos() == ObjectList[k]->getYPos())
						{
							ObjectList[j]->ChangePos(ObjectList[k]);
							break;
						}
					}
				else if (random == 2)
					for (int k = 0; k < 16; k++)
					{
						if (ObjectList[j]->getXPos() == ObjectList[k]->getXPos() && ObjectList[j]->getYPos() - 150 == ObjectList[k]->getYPos())
						{
							ObjectList[j]->ChangePos(ObjectList[k]);
							break;
						}
					}
				else if (random == 3)
					for (int k = 0; k < 16; k++)
					{
						if (ObjectList[j]->getXPos() == ObjectList[k]->getXPos() && ObjectList[j]->getYPos() + 150 == ObjectList[k]->getYPos())
						{
							ObjectList[j]->ChangePos(ObjectList[k]);
							break;
						}
					}
			}
		}
		timer->set(0.01f);
		if (count < 120)
		{
			timer->start();
			count++;
		}
		else
		{
			bStart = true;
			checktimer->set(0.f);
			checktimer->start();
		}
		return true;
		});
	checktimer->setOnTimerCallback([&](TimerPtr timer)->bool {

		checktimer->set(1.f);
		checktimer->start();
		checktime += 1;
		return true;
		});
	startGame(scene1);
	return 0;
}