#pragma once
#include <bangtal.h>
using namespace bangtal;
class Card
{

private:
	int num;			//(int)num/4 �� �� -1 �� �����Ѵ�.  
	ObjectPtr CardObject;
	ScenePtr SceneObject;
public:

	Card(int _num ,ObjectPtr _PersolObject)
	{
		num = _num;
		CardObject = _PersolObject;
	}

	int getNum() { return num; }
	
	std::shared_ptr<Object> getCardObject() 
	{
		return CardObject;
	};

};